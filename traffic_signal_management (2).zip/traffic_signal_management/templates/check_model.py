import os

model_path = "models/yolov8n.pt"

# Check if the YOLOv8 model exists
if os.path.exists(model_path):
    print(f"Model found: {model_path}")
else:
    print(f"Model not found at {model_path}. Please download it.")